package org.example.database;

import org.example.database.model.SportObject;

import java.sql.*;

public class SqliteConnection {
    public static Connection connection;
    public static Statement statement;
    public static ResultSet resultSet;

    public SqliteConnection(String databaseName) throws ClassNotFoundException, SQLException {
        Class.forName("org.sqlite.JDBC");
        connection = DriverManager.getConnection(String.format("jdbc:sqlite:%s", databaseName));
    }

    public void query1() throws SQLException {
        statement = connection.createStatement();
        resultSet = statement.executeQuery("SELECT AVG(number) FROM sport_object;");
        System.out.println("Среднее количество регионов спорта:");
        while (resultSet.next()) {
            int avgNumber = resultSet.getInt(1);
            System.out.printf("%d\n", avgNumber);
        }
    }

    public void query2() throws SQLException {
        statement = connection.createStatement();
        resultSet = statement.executeQuery("SELECT subject,COUNT(number) FROM sport_object GROUP BY subject ORDER BY COUNT(number) DESC LIMIT 3;");
        System.out.println("Регион Количество обьектов спорта");
        while (resultSet.next()) {
            String subject = resultSet.getString(1);
            int count = resultSet.getInt(2);
            System.out.printf("%s %d\n", subject, count);
        }
    }

    public void createTables() throws SQLException {
        statement = connection.createStatement();
        statement.execute("CREATE TABLE if not exists 'sport_object' ('number' INTEGER PRIMARY KEY , 'name' text, 'subject' text, 'address' text, 'date' text);");
        System.out.println("Таблица создана или уже существует.");
    }

    public void insertSportObject(SportObject sportObject) {
        try {
            statement = connection.createStatement();
            statement.execute(String.format("INSERT INTO 'sport_object' ('number', 'name','subject','address','date') VALUES (%d, '%s','%s','%s','%s');", sportObject.getNumber()
                    , sportObject.getName()
                    , sportObject.getSubject()
                    , sportObject.getAddress()
                    , sportObject.getDate()));
        } catch (SQLException e) {

        }
    }

    public void close() throws SQLException {
        connection.close();
        statement.close();
        resultSet.close();
    }

}
