package org.example;

import com.opencsv.bean.CsvToBeanBuilder;
import org.example.database.SqliteConnection;
import org.example.database.model.SportObject;

import java.io.*;
import java.sql.SQLException;
import java.util.List;

public class Main {

    public static void main(String[] args) throws FileNotFoundException, SQLException, ClassNotFoundException {
        SqliteConnection sqliteConnection = new SqliteConnection("database.sqlite");
        sqliteConnection.createTables();
        List<SportObject> sportObjects = readCsv("Объекты спорта.csv");

        for (SportObject sportObject : sportObjects) {
            sqliteConnection.insertSportObject(sportObject);
            System.out.println(sportObject);
        }

        sqliteConnection.query1();
        sqliteConnection.query2();

    }

    public static List<SportObject> readCsv(String fileName) throws FileNotFoundException {
        return (List<SportObject>) new CsvToBeanBuilder(new FileReader(fileName)).withSkipLines(1).withType(SportObject.class).build().parse();
    }

}